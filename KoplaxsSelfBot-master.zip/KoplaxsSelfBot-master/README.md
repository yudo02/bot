# KoplaxsSelfBot
Koplaxs Self Bot
Basic Sc By : LINE TCR
============================================
Bot Protect Versi Selfbot 1 admin dan 10 Bot
============================================
Bot Protect TCR Versi Selfbot
-Siapkan 1 Akun Utama Dan 10 Akun Bot  + 1 Akun Untuk Backup
Apa Gunanya Bot Backup? 
Untuk Membackup Akun Utama Jika Ga ada di room
BOT Backup ini Adanya Di Luar Group :D
Jadi Di Gunakan Jika Kalo Situasi Darurat :v


Fungsinya?
Kelebihan :
1.Protect Group Line Pastinya
2.Bisa Invite Semua Bot Lewat Command Tanpa Bot Induk
3.Bot Tidak Saling Kick Ketika Ada Yang Terkick

Kelemahan:
1.Tidak Bisa Nambah Admin/Staff
2.Command Tidak Bisa Dipakai oleh Orang Lain
3.Jika Ingin Protect Lebih Dari 1 Group, Kalian Wajib ada di Semua Group Tersebut

Cara Instal :
- pkg install python2 -y
- pkg install git -y
- git clone https://github.com/koplaxs/KoplaxsSelfBot
- pip2 install rsa
- pip2 install thrift==0.9.3
- pip2 install requests

Cara Menjalankan Botnya :
- cd KoplaxsSelfBot
- python KoplaxsSelfBot.py

Ada Pertanyaan?
Add My Line => @hanavy1992

Thanks For :
- Alfathdirk
- Farzain
- Dan Kawan²
